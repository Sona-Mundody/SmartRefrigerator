# SmartFridge > 2022-06-19 12:13am
https://universe.roboflow.com/object-detection/smartfridge-ztup8

Provided by Roboflow
License: CC BY 4.0

